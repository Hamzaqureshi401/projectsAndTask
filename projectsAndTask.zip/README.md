Step1: make a database in phpmyadmin name with laravel

Step2: php artisan migrate

Step3: php artisan serve

step4: copy serve url in browser http://127.0.0.1:8000/
