

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>Add Project</h2>
        <form action="/projects" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Project Name:</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectsAndTask\resources\views/projects/createProject.blade.php ENDPATH**/ ?>