

<?php $__env->startSection('content'); ?>
   <table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Actions</th> <!-- Add an actions column -->
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($project->id); ?></td>
                <td><?php echo e($project->name); ?></td>
                <td>
                    <a href="<?php echo e(route('project.tasks', ['projectId' => $project->id])); ?>" class="btn btn-primary">View Tasks</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectsAndTask\resources\views/projects/allProjects.blade.php ENDPATH**/ ?>