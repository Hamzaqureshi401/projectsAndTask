
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2>All Tasks</h2>

        <table id="myTable" class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Task Name</th>
                    <th>Priority</th>
                    <th>Project Name</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody class="sort">
                <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr style="cursor: pointer;" class="sortable-row" id="<?php echo e($loop->index); ?>" data-task-id="<?php echo e($task->id); ?>">
                        <td><?php echo e($task->id); ?></td>
                        <td><?php echo e($task->task_name); ?></td>
                        <td><?php echo e($task->priority); ?></td>
                        <td><?php echo e($task->project->name); ?></td>
                        <td><?php echo e($task->created_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('editTask', $task->id)); ?>" class="btn btn-primary">Edit</a>
                            <form action="<?php echo e(route('deleteTask', $task->id)); ?>" method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>



       $(document).ready(function() {
    $('#myTable tbody').sortable({
        cursor: 'move',
        axis: 'y',
        update: function(e, ui) {
            var changedRowIds = [];
            $('#myTable tbody tr').each(function(index) {
                var taskId = $(this).data('task-id');
                changedRowIds.push(taskId);
            });

            console.log('Changed row IDs:', changedRowIds);
            
            $.ajax({
                type: 'POST',
                url: '/reOrderTask',
                data: { changedRowIds: changedRowIds,
                _token: '<?php echo e(csrf_token()); ?>',
                 }, 
                success: function(response) {
                    console.log("Priorities updated successfully.");
                     if (response) {
                            alert(response.message);
                        }
                },
                
            });
        }
    });
});


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectsAndTask\resources\views/tasks/allTasks.blade.php ENDPATH**/ ?>